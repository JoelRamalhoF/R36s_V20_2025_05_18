# GUIA DEFINITIVO & PULL REQUEST: R36S CLONE (PLACA V20 2025-05-18 2541 - PAINEL K36)

> **Autor / Criador:** Joel Ramalho ([@JoelRamalhoF](https://github.com/JoelRamalhoF))  
> **Co-piloto Técnico:** Antigravity (Google DeepMind)  
> **Repositório Oficial:** [JoelRamalhoF/R36s_V20_2025_05_18](https://github.com/JoelRamalhoF/R36s_V20_2025_05_18)  
> **Sistemas Testados e Validados:** Omni36OS (PortMaster) & DArkOSen (ArkOS)

Este diretório contém a **solução definitiva, testada e 100% validada** para suportar a revisão de placa clone `R36S-V20 2025-05-18 2541` (conhecida como K36) no **Omni36OS**, **ArkOS**, **DArkOSen** e demais distribuições baseadas no RK3326.

---

## 1. Identificação do Hardware
- **Console:** R36S Clone (Revisão 2025).
- **Inscrição na Motherboard:** `R36S-V20 2025-05-18 2541` (Placa clone da família G80C/G80CA).
- **Painel:** KD35T133 (DSI 4-lanes, 640x480 @ 30 MHz, DCS 370 bytes, compatível com perfil Painel 8).
- **Mapeamento de Pinos do Display:**
  - **Reset do LCD:** `GPIO3_B7` (Pino 15, active-low) -> `<104 15 1>`. *(Diferente do G80C comum que usa pino 27)*.
  - **Alimentação/Enable do LCD (`vcc18_lcd0`):** `GPIO0_B5` (Pino 13, active-high) -> `<94 13 0>`. *(Diferente do G80C comum que usa pino 3)*.
- **Mapeamento dos Analógicos & Controles:**
  - **AMUX Enable (Multiplexador ADC):** `GPIO2_B4` (Pino 12) -> `<195 12 1>`. *(Diferente do G80C comum que usa pino 11)*.
  - **Deadzone:** `64`.
  - **Inversão de Eixos:**
    - Analógico Esquerdo: `invert-absx`, `invert-absy` (necessário para orientar X e Y).
    - Analógico Direito: padrão não invertido (Cima=Cima, Baixo=Baixo, Esquerda=Esquerda, Direita=Direita).
  - **Mapeamento de Botões:** `sw7 = GPIO BTN-Y`, `sw8 = GPIO BTN-X`.
- **Mapeamento de Áudio:**
  - **Detecção de Fone P2 (`hp-det-gpio`):** `GPIO2_C6` (Pino 22, active-high) -> `<195 22 0>`. Corrige a chave normalmente fechada do conector P2 para não mutar o alto-falante quando sem fone.

---

## 2. Conteúdo Completo dos Arquivos de Boot / DTB

| Arquivo | Tamanho | Função |
| :--- | :--- | :--- |
| **`rk3326-r36s-linux.dtb`** | 92.433 bytes | DTB oficial do Kernel Linux (nome padrão do Omni36OS/ArkOS). |
| **`rk3326-k36-linux.dtb`** | 92.433 bytes | Cópia idêntica do DTB (utilizado por outros sistemas como DArkOSen/ArkOS4Clone). |
| **`rg351v-uboot.dtb`** | 59.519 bytes | DTB do Bootloader U-Boot com pinos K36 (evita LED vermelho no R36S clone). |
| **`rg351mp-uboot.dtb`** | 59.519 bytes | DTB alternativo do U-Boot para compatibilidade. |
| **`rg351p-uboot.dtb`** | 59.519 bytes | DTB alternativo do U-Boot para compatibilidade. |
| **`boot.ini`** | 523 bytes | Configuração de boot testada e funcional (`console=tty1`). |
| **`gerar_dtbs_k36.py`** | ~3.5 KB | Script em Python para reproduzir o patch a qualquer momento. |
| **`MEMORY.md`** | Documentação | Registro técnico e histórico de engenharia reversa. |

---

## 3. Como Criar o Pull Request (PR) para o Omni36OS / ArkOS

Para submeter ao mantenedor do repositório oficial do sistema:

### Estrutura de Pastas no Repositório:
```text
dtb/clone/R36S-V20 2025-05-18 2541 (K36)/
├── boot.ini
├── rg351mp-uboot.dtb
├── rg351p-uboot.dtb
├── rg351v-uboot.dtb
├── rk3326-k36-linux.dtb
└── rk3326-r36s-linux.dtb
```

### Mensagem Pronta para o Pull Request (no GitHub):

**Title:**  
`Add support for R36S clone board V20 2025-05-18 2541 (K36 panel, controls & audio fix)`

**Description:**  
```markdown
### Summary
This PR adds full out-of-the-box support for the new R36S clone motherboard revision marked as `R36S-V20 2025-05-18 2541` (known as K36 panel).

### Tested Hardware & Systems
- Tested on physical hardware running **Omni36OS** and **DArkOSen**.
- Display KD35T133 (Panel 8 DCS init) initializes cleanly with no red LED.
- Memory timings rebased onto safe factory 786 MHz clocks, eliminating the arm64 SIGSEGV `exitcode=0x0000000b` kernel panic.
- Controls: AMUX enable switched to GPIO2_B4 (Pin 12) with deadzone 64 and calibrated analog directions.
- Audio: Inverted headphone jack detection logic fixed to GPIO_ACTIVE_HIGH (0) on GPIO2_C6 (Pin 22), resolving the silent internal speaker issue.
```
