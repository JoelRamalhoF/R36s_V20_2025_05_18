# GUIA DEFINITIVO & PULL REQUEST: R36S CLONE (PLACA V20 2025-05-18 2541 - PAINEL K36)

Este diretório contém a **solução definitiva, testada e 100% validada** para suportar a revisão de placa clone `R36S-V20 2025-05-18 2541` (conhecida como K36) no **Omni36OS**, **ArkOS**, **DArkOSen** e demais distribuições baseadas no RK3326.

---

## 1. Identificação do Hardware
- **Console:** R36S Clone (Revisão 2025).
- **Inscrição na Motherboard:** `R36S-V20 2025-05-18 2541` (Placa clone da família G80C/G80CA).
- **Painel:** KD35T133 (DSI 4-lanes, 640x480 @ 30 MHz, DCS 370 bytes, compatível com perfil Painel 8).
- **Mapeamento de Pinos do Display:**
  - **Reset do LCD:** `GPIO3_B7` (Pino 15, active-low) -> `<104 15 1>` *(diferente do G80C comum que usa pino 27)*.
  - **Alimentação/Enable do LCD (`vcc18_lcd0`):** `GPIO0_B5` (Pino 13, active-high) -> `<94 13 0>` *(diferente do G80C comum que usa pino 3)*.
- **Mapeamento dos Analógicos & Controles:**
  - **AMUX Enable (Multiplexador ADC):** `GPIO2_B4` (Pino 12) -> `<195 12 1>` *(diferente do G80C comum que usa pino 11)*.
  - **Deadzone:** `64`.
  - **Inversão de Eixos:**
    - Analógico Esquerdo: `invert-absx`, `invert-absy` (necessário para orientar X e Y).
    - Analógico Direito: padrão não invertido (Cima=Cima, Baixo=Baixo, Esquerda=Esquerda, Direita=Direita).
  - **Mapeamento de Botões:** `sw7 = GPIO BTN-Y`, `sw8 = GPIO BTN-X`.

---

## 2. Conteúdo Completo dos Arquivos de Boot / DTB

| Arquivo | Tamanho | Função |
| :--- | :--- | :--- |
| **`rk3326-r36s-linux.dtb`** | 92.433 bytes | DTB oficial do Kernel Linux (nome padrão do Omni36OS/ArkOS). |
| **`rk3326-k36-linux.dtb`** | 92.433 bytes | Cópia idêntica do DTB (utilizado por outros sistemas como DArkOSen/ArkOS4Clone). |
| **`rg351v-uboot.dtb`** | 59.519 bytes | DTB do Bootloader U-Boot com pinos K36 (evita LED vermelho no R36S clone). |
| **`rg351mp-uboot.dtb`** | 59.519 bytes | DTB alternativo do U-Boot para compatibilidade. |
| **`rg351p-uboot.dtb`** | 59.519 bytes | DTB alternativo do U-Boot para compatibilidade. |
| **`boot.ini`** | 523 bytes | Configuração de boot testada e funcional. |
| **`gerar_dtbs_k36.py`** | ~3 KB | Script em Python para reproduzir o patch a qualquer momento. |

---

## 3. Como Criar o Pull Request (PR) para o Omni36OS / ArkOS

Para submeter ao mantenedor do repositório oficial do sistema:

### Estrutura de Pastas no Repositório:
```text
dtb/clone/R36S-V20 2025-05-18 2541 (K36)/
├── boot.ini
├── rg351mp-uboot.dtb
├── rg351p-uboot.dtb
├── rg351v-uboot.dtb
├── rk3326-k36-linux.dtb
└── rk3326-r36s-linux.dtb
```

### Mensagem Pronta para o Pull Request (no GitHub):

**Title:**  
`Add support for R36S clone board V20 2025-05-18 2541 (K36 panel & controls)`

**Description:**  
```markdown
### Summary
Adds verified DTB support for the R36S clone motherboard revision `R36S-V20 2025-05-18 2541` (often referred to as K36).

### Hardware Specifications & Tested Configuration:
- **Motherboard:** R36S-V20 2025-05-18 2541
- **LCD Panel:** KD35T133 (Panel 8 init sequence, 370-byte DCS)
- **LCD Reset GPIO:** GPIO3_B7 (Pin 15, active-low) -> `<104 15 1>`
- **LCD Power Enable GPIO (vcc18_lcd0):** GPIO0_B5 (Pin 13, active-high) -> `<94 13 0>`
- **Analog Multiplexer Enable (amux-en-gpios):** GPIO2_B4 (Pin 12) -> `<195 12 1>`
- **Sticks Calibration:**
  - Left stick: inverted X and Y (`invert-absx`, `invert-absy`)
  - Right stick: standard orientation (no inversion required)
  - Deadzone: 64
- **DRAM & CPU Timings:** Safe stock frequencies (max 786 MHz DDR3 / 1512 MHz CPU) to prevent the `exitcode=0x0000000b` SIGSEGV kernel panic on arm64 systemd init.

### Verification:
Fully tested on hardware running Omni36OS: U-Boot logo displays correctly, firstboot partition expansion completes to 100%, and EmulationStation/gamepad test confirms perfect centering and axis direction on both sticks.
```
